package com.naik.awss3;

import com.amazonaws.AmazonServiceException;
import com.amazonaws.SdkClientException;
import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import com.amazonaws.services.s3.model.*;
import org.apache.commons.io.FileUtils;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import java.util.List;

public class Main {
    public static void main(String[] args) throws Exception {

        String accessKey = "";
        String secretKey = "";
        AWSCredentials credentials = new BasicAWSCredentials(
                accessKey,
                secretKey
        );
        AmazonS3 s3client = AmazonS3ClientBuilder
                .standard()
                .withCredentials(new AWSStaticCredentialsProvider(credentials))
                .withRegion(Regions.US_EAST_1)
                .build();


        String bucketName = "";


        try {
            //uploadContent(s3client, bucketName, "naik/xyz.txt", "This is an xyz content.");
            delete(s3client, bucketName, "naik/abcd.txt");

        }catch (S3POCException e){
            System.out.println("An error occurred with code : "+e.getErrorCode()+" and description : "+ e.getErrorDescription());
        }
        catch (Exception e) {
            System.out.println("An unknown error occured.");
            e.printStackTrace();
        }

    }


    public static void list(AmazonS3 s3client, String bucketName, String key, String localFile) throws S3POCException {

        try {
            ObjectListing objectListing = s3client.listObjects(bucketName);
            for (S3ObjectSummary os : objectListing.getObjectSummaries()) {
                System.out.println(os.getKey());
            }
        } catch (AmazonServiceException e) {
            e.printStackTrace();
            throw new S3POCException("S3_SERVER_ERROR", "Error occurred while listing files");
        } catch (SdkClientException e) {
            e.printStackTrace();
            throw new S3POCException("S3_CLIENT_ERROR", "Error occurred while listing files");
        }
    }

    public static void download(AmazonS3 s3client, String bucketName, String key, String localFile) throws S3POCException {

        try {
            S3Object s3object = s3client.getObject(bucketName, key);
            S3ObjectInputStream inputStream = s3object.getObjectContent();
            FileUtils.copyInputStreamToFile(inputStream, new File(localFile));
        } catch (AmazonServiceException e) {
            e.printStackTrace();
            throw new S3POCException("S3_SERVER_ERROR", "Error occurred while downloading files");
        } catch (SdkClientException e) {
            e.printStackTrace();
            throw new S3POCException("S3_CLIENT_ERROR", "Error occurred while downloading files");
        } catch (IOException e) {
            e.printStackTrace();
            throw new S3POCException("TECHNICAL_ERROR", "Error occurred while downloading files");
        }
    }

    public static void upload(AmazonS3 s3client, String bucketName, String key, String localFile) throws S3POCException {
        try {
            s3client.putObject(bucketName, key, new File(localFile));

        } catch (AmazonServiceException e) {
            e.printStackTrace();
            throw new S3POCException("S3_SERVER_ERROR", "Error occurred while uploading files");
        } catch (SdkClientException e) {
            e.printStackTrace();
            throw new S3POCException("S3_CLIENT_ERROR", "Error occurred while uploading files");
        }
    }

    public static void uploadContent(AmazonS3 s3client, String bucketName, String key, String content) throws S3POCException {
        try {
            s3client.putObject(bucketName, key, content);

        } catch (AmazonServiceException e) {
            e.printStackTrace();
            throw new S3POCException("S3_SERVER_ERROR", "Error occurred while creating files");
        } catch (SdkClientException e) {
            e.printStackTrace();
            throw new S3POCException("S3_CLIENT_ERROR", "Error occurred while creating files");
        }
    }

    public static void delete(AmazonS3 s3client, String bucketName, String key) throws S3POCException {
        try {
            s3client.deleteObject(bucketName, key);

        }  catch (AmazonServiceException e) {
            e.printStackTrace();
            throw new S3POCException("S3_SERVER_ERROR", "Error occurred while deleting files");
        } catch (SdkClientException e) {
            e.printStackTrace();
            throw new S3POCException("S3_CLIENT_ERROR", "Error occurred while deleting files");
        }
    }

}