package com.enact.lenderservice.b2binjest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.b2binjest", "com.enact.lenderservice.b2binjest.repository"})
public class B2binjestApplication {

	public static void main(String[] args) {
		SpringApplication.run(B2binjestApplication.class, args);
	}

}
