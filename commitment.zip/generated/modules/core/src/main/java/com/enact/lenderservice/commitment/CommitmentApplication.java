package com.enact.lenderservice.commitment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.commitment", "com.enact.lenderservice.commitment.repository"})
public class CommitmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommitmentApplication.class, args);
	}

}
