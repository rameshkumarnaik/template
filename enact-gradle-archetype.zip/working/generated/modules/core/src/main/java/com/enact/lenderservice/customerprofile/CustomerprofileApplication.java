package com.enact.lenderservice.customerprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.customerprofile", "com.enact.lenderservice.customerprofile.repository"})
public class CustomerprofileApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerprofileApplication.class, args);
	}

}
