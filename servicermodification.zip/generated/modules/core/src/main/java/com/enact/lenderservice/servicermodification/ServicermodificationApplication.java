package com.enact.lenderservice.servicermodification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.servicermodification", "com.enact.lenderservice.servicermodification.repository"})
public class ServicermodificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicermodificationApplication.class, args);
	}

}
