package com.enact.lenderservice.activation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.activation", "com.enact.lenderservice.activation.repository"})
public class ActivationApplication {

	public static void main(String[] args) {
		SpringApplication.run(ActivationApplication.class, args);
	}

}
