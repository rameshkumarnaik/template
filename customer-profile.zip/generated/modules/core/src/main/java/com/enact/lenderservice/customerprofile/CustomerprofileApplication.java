package com.enact.lenderservice.customerprofile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.customerprofile"})
@EntityScan({"com.enact.lenderservice.customerprofile.data.entity"})
public class CustomerprofileApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerprofileApplication.class, args);
	}

}
