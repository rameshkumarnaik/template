package com.enact.lenderservice.policysearch;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.policysearch", "com.enact.lenderservice.policysearch.repository"})
public class PolicysearchApplication {

	public static void main(String[] args) {
		SpringApplication.run(PolicysearchApplication.class, args);
	}

}
