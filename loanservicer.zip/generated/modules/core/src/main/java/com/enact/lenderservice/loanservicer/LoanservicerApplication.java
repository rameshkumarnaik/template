package com.enact.lenderservice.loanservicer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.loanservicer", "com.enact.lenderservice.loanservicer.repository"})
public class LoanservicerApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanservicerApplication.class, args);
	}

}
