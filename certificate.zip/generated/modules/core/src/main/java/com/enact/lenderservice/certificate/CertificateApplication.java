package com.enact.lenderservice.certificate;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@ComponentScan({"com.enact.lenderservice.certificate"})
@EntityScan({"com.enact.lenderservice.certificate.data.entity"})
public class CertificateApplication {

	public static void main(String[] args) {
		SpringApplication.run(CertificateApplication.class, args);
	}

}
